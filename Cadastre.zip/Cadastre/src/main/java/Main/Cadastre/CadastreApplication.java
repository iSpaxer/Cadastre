package Main.Cadastre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastreApplication.class, args);
	}

}
